# Toriola Korede — Online Portfolio

This folder contains a single-page portfolio website.

## How to get a public link
1. Create/sign in to a GitHub account.
2. Create a new public repository, for example: `toriola-korede-portfolio`.
3. Upload `index.html`.
4. In the repository, open Settings → Pages.
5. Select the main branch as the source and save.
6. GitHub will provide a public website link.

Use that public link in the Prime Startups form under:
“Link to anything you've made (portfolio...)”.

Before publishing, replace/add any project photos, LinkedIn URL, social links, certificates or documents you want to showcase.
